---
bookToc: true
title: Where Will China Get Its Protein?
weight: 2
---

{{< hint info >}}

# **Where Will China Get Its Protein?**

{{< /hint >}}

---

{{< hint warning >}}

## **Contents**

1. China meat consumption

2. China meat production

3. Trade idea: Long alt-meat

4. Trade idea: Long agri-tech / animal health

{{< /hint >}}

{{< hint danger >}}

*Not investment advice. Do your own research.

{{< /hint >}}

---

# **1. China Meat Consumption**

Comparatively per capita, China consumes an average amount of meat, mostly pork.

![Image alt](/images/tidbits/pork_1.png)

In absolute terms (tonnes of meat consumed), no other country’s even close. It’s ridiculous.

![Image alt](/images/tidbits/pork_2.png)

---

# **2. China Meat Production**

China’s per capita meat production has hit some snags. Y-axis is kg/capita/year.

![Image alt](/images/tidbits/pork_3.png)

Cost of protein. Beef cannot make up for shortfalls in protein production for one reason: land constraints. It’s going to be either pork or poultry. Asia has way too many people on too little land.

![Image alt](/images/tidbits/pork_4.png)

---

# **3. Trade Idea: Long Alternative Meat**

Thesis: _Increasing meat consumption is unsustainable, must find suitable substitutes._

- DEMAND: Health and environmental concerns push for lower meat intake. So will rising pork prices. But people still want meat-like products.

- SUPPLY: Traditional meat production has hit a ceiling because of land use constraints, growing pains in supply (e.g. swine fever, small scale farms), and simply because the absolute values consumed are already so high. There are (likely) hard limits to how much more China can produce.

## Listed companies with Alternative Meat exposure

- **Beyond Meat (BYND US)** - Develops plant based protein food products and opened its first international factory in Jiaxing, China this year. In 2020, Beyond Meat's revenues were US$406.8 million, up 36.6% from 2019. International sales were 20% of 2020 sales and declined 16.5% from 2019 levels. Beyond Meat has yet to earn a profit and trades at US$4.9 billion market cap, or about 7.4 times 2022 sales estimates.

- **AgriNurture Inc (ANI PM)** - A Philippine agricultural company that exports fresh product and processed foods, including plant based meat. They are launching new plant based meat products under the name "Fit Bites." AgriNurture also engages in Real Estate development in China. Their 2020 revenues were PHP 4.4 billion, about 52% were earned in Hong Kong/China. 2020 net sales declined 2.8% from 2019 levels. AgriNurture's market cap is PHP 6.6 billion.

## Further reading

- [USDA on plant based alt-meat trends in China (includes list of companies)](https://apps.fas.usda.gov/newgainapi/api/Report/DownloadReportByFileName?fileName=Market%20Overview%20of%20Plant-Based%20Meat%20Alternative%20Products%20in%20China_Beijing_China%20-%20Peoples%20Republic%20of_01-07-2021)

> In the past few years, driven by novelty and perceived health benefits, consumers have become interested in plant-based meat alternatives […]

> Most domestic plant-based meat alternative companies are start-up businesses that are using venture capital funding to innovate and expand revenue. Since 2019, at least one dozen plant-based meat alternative companies have emerged. Most domestic companies are focused on reaching consumers first through the restaurant industry, while a few are exploring direct-to-consumer sales models, especially growing e-commerce sales for at-home consumption and snack foods.

- [Vegan meat market in China - analysis by local consultancy](https://daxueconsulting.com/vegan-meat-in-china/)

> […] the times are changing and younger Chinese are noticing the negative side of eating an abundance of meat. Nowadays, health and weight concerns are among the main reasons why Chinese people reduce their meat intake […]

> Today’s biggest producers and suppliers of alternative meat are situated in Europe and North America.

> […] in the last 5 years numerous plant-based raw ingredients providers have sprung up in China, thanks to investment and incubator programs.

- [Time article on meat in China](https://time.com/5930095/china-plant-based-meat/)

> The buzz around Green Common is another sign that China is on the cusp of a plant-based-protein revolution that has investors as well as diners licking their lips.

> The largest impact may be not on the economy but on the environment. China has already pledged to see carbon emissions peak by 2030 and make the world’s worst polluter carbon-neutral by 2060. As livestock farming produces 20% to 50% of all man-made greenhouse gases, finding alternative protein sources is crucial to meeting these targets.

- [TechCrunch article on alt-meat Chinese startups](https://techcrunch.com/2021/04/05/plant-based-meat-startups-china/)

> 2020 could well have been the dawn of alternative protein in China. More than 10 startups raised capital to make plant-based protein for a country with increasing meat demand. Of these, Starfield, Hey Maet, Vesta and Haofood have been around for about a year; ZhenMeat was founded three years ago; and the aforementioned Green Monday is a nine-year-old Hong Kong firm pushing into mainland China. The competition intensified further last year when American incumbents Beyond Meat and Eat Just entered China.

- [Beyond Meat opens China factory, its first outside US](https://agfundernews.com/beyond-meat-opens-factory-in-china-its-first-outside-us.html)

> [Beyond Meat] will churn out variations on Beyond Pork, which the company described as its “first innovation created specifically for the Chinese market.”

---

# **4. Trade Idea: Long Agri-tech / Animal health**

Thesis: _Demand for meat will continue to grow. This can be met by technological supply-side solutions._

- DEMAND: People won’t stop eating meat. Especially as urbanisation continues. And they (largely) will not accept meat substitutes.

- SUPPLY: Animal health (biotech) and productivity efficiency gains (smart agri-tech) in meat production can solve current supply issues.

## Listed companies with Animal Health exposure

- **Jinyu Bio-Technology (600201 CH)** - 2020 sales of CNY 1.58 billion, up 40% from 2019. Jinyu is in the animal disease prevention and control business. They provide veterinary biologic products covering pigs, poultry, ruminants and pets of more than 100 kinds of animal vaccines. Jinyu’s market cap is CNY 18.5 billion, 21.6 times 2022 consensus earnings.

- **China Animal Husbandry (600195 CH)** - 2020 sales of CNY 5.0 billion, up 20.9% from 2019. CAH engages in the research and development, production, sale, and service of animal health and nutrition products. CAH’s market cap is CNY 11.75 billion, 18.4 times 2022 consensus earnings.

- **Zoetis Inc (ZTS US)** - Zoetis is a global leader in animal health with US$6.67 billion in 2020 sales (up 7.8% from 2019). They focus on vaccines, other animal pharmaceuticals, anti-infectives, parasiticides, medicated feed additives, animal health diagnostics both to livestock and companion animals. Since 2019 over 50% of their revenue comes from companion animals. In 2020 Zoetis increased their sales in China by 33% to US$266 million, 50% of which was livestock. Zoetis has an R&D center in Beijing, a R&D+ manufacturing in Suzhou, Jiangsu and plants in Tonghua, Jilin and Suzhou, Jiangsu. Currently, Zoetis is building a second manufacturing plant in Suzhou. Zoetis market cap is USD 107 billion, 44 times 2022 consensus earnings.

- **Listed Agri-tech exposure** - We believe China big tech platforms with their investments in the space offer an option for public market investors. Note, most of the investments have been in eGrocery or marketplace deals rather than upstream technology. While not a pure play, they could benefit from increasing meat/alt meat consumption in China. These platforms are Tencent, Pinduoduo, Alibaba, Baidu, Meituan and Didi.

## Further reading

- [Huawei enters smart pig farming](https://www.asiafinancial.com/huawei-to-use-ai-and-high-tech-to-create-smart-pig-farming)

> With Huawei predicting its mobile shipments could fall 60% this year, the company has made a surprising turn – into the pig farming business.

> Many tech firms globally are getting into the food production business and in China this is especially relevant, as food shortages are a major fear because of endemic livestock problems […]

> The State Council Information Office held a press conference on Monday February 22 introduce moves to revitalise and ramp up agricultural and rural modernisation […]

- [AI assisted pig farming](https://www.theguardian.com/environment/2020/oct/08/behind-chinas-pork-miracle-how-technology-is-transforming-rural-hog-farming)

> In China, 98% of pork farms have fewer than 50 animals, and account for about a third of the country’s pork production. These highly decentralised farms make government oversight difficult. There is also enormous pressure on them to keep to the market price for pork, and to maintain steady production. The government was using ASF as a convenient excuse to eradicate these small farms, making way for centralised, industrial-scale operations.
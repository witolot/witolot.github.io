---
bookToc: true
title: What Can We Glean From Company Filings (Without Actually Reading Them)?
weight: 3
---

{{< hint info >}}

# **What Can We Glean From Company Filings (Without Actually Reading Them)?**

{{< /hint >}}

---

{{< hint warning >}}

## **Contents**

1. Plotting Change in Filings

2. Top Words by Salience

3. Sentiment Analysis

4. Takeaways

{{< /hint >}}

{{< hint danger >}}

*Not investment advice. Do your own research.

{{< /hint >}}

---

# **Why You Should Read This Post**

Equity analysts have their plates full. Particularly during earnings season. While the quantitative analysis shown below cannot replicate the work of a good analyst, it can help one. During earnings season, one can take a quick glance -- particularly at the change scores -- to quickly determine which 10-Ks one should work through first. It can help an analyst rank order their stack of 10-Ks to read through.

---

# **Exec Summary**

Company filings (e.g. 10-K, 10-Q, 20-F) can be dense and lengthy. For equity investors, it’s not easy getting through them. Are there any methods we can apply to prioritise which filings to read first and identify what to keep an eye on, all before actually digging in and reading them? This issue we sift through Apple’s 10-K filings at the SEC as a case study.

![Image alt](/images/quant/filings_1.png)

Using change scores between a company's year-on-year filings (see chart above), at a glance one can determine whether something has changed. The changers may warrant special attention over the non-changers.

---

# **1. Plotting Change in Filings**

We first extract one of the sections of most interest — “Item 7: Management Discussion & Analysis” — and try to quantify the year-on-year change.

![Image alt](/images/quant/filings_1.png)

Our change score is a textual (word composition & frequency) comparison of the section from one year to the year prior. For example, a data point for 2020 indicates the scoring of the 2020 filing versus the 2019 filing. A score == 0 means no change (likely comparing the same document). At a glance, the change score answers the question "Did something change?" or “Should this be the first filing I read?.

In the case of AAPL, it’s clear that something was already afoot in 2005 and again in 2006, all before the spike in 2007. Jobs only announced the iPhone on Jan. 9, 2007 at the MacWorld Expo (source [here](https://www.cnet.com/tech/mobile/the-iphone-at-15-steve-jobs-revealed-his-great-product-15-years-ago/#:~:text=00%20a.m.%20PT-,On%20Jan.,Job%20unveiled%20the%20first%20iPhone.&text=Fifteen%20years%20ago%20today%2C%20Steve,a%20phone%20and%20internet%20communicator.))

---

# **2. Top Words by Salience**

We extract words from the filings and then score them based on their frequency within a particular 10-K versus their frequency in the company's other 10-Ks. The point is to try to identify words that are rare (so they don't show up high in frequency counts) but which could be significant in the context of a particular filing. The words are stemmed, e.g. "fraud" and "fraudulent" are treated the same as their common stem is "fraud"; "restructur" is the stem of "restructure", "restructuring", "restructured", which all are semantically similar. Wearables become a thing in 2019 and 2020.

![Image alt](/images/quant/filings_2.png)

And here are the salience scores for the words from the above table. Just to illustrate, the top_1 word in 1999 has a score of 69.90, meaning it doesn’t really show up anywhere else, what’s so special about it? Go back up and find that it corresponds to word “y2k”, i.e. the year 2000 when humanity was kind of panicking whether computer clocks would blow up going into 2000. Another example, 2007, very exceptional MD&A section versus Apple’s other filings; mostly about compensation to Jobs for pulling it all off? (iPhone announced January, filing filed end of September).

![Image alt](/images/quant/filings_3.png)

---

# **3. Sentiment Analysis**

Here we use the Loughran & McDonald Master Dictionary, a finance specific dictionary with codings for sentiment. Just for flavour, see lower down for sample list of words for the sentiment codings.

![Image alt](/images/quant/filings_4.png)

Some observations:

- Litigious wording increased strongly going into the 2000s before slope of trend abated somewhat after;

- Negative wording fell sharply after 2005;

- Strong wordings have their 1-3 year periods of surfacing now and then;

- Uncertainty wordings for the company bottomed in 2007 and remained incredibly steady thereafter. Again, after the release of the iPhone things became more certain, which is reflected in the textual discussions in the 10-K.

![Image alt](/images/quant/filings_5.png)
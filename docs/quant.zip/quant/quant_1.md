---
bookToc: true
title: From Consumer Complaints to Investment Alpha for US Financial Companies
weight: 1
---

{{< hint info >}}

# **From Consumer Complaints to Investment Alpha for US Financial Companies**

{{< /hint >}}

---

{{< hint warning >}}

## **Contents**

1. Data Sourcing

2. Feature Selection

3. Textual Analysis

4. Deriving Variables

5. Quantile Segmentation

6. Plotting Portfolio Performance

{{< /hint >}}

{{< hint danger >}}

*Not investment advice. Do your own research.

{{< /hint >}}

---

# **Why You Should Read This Post**

There's a lot of data out there. But most people think it only has to be numeric. 
The exercise herein is really about whether one can turn text itself into actionable data.
And since we prove below that we can, this unlocks a whole new world of possibilities for extracting
alpha from text sources. Consumer complaints, filings like 10-Ks, or even analyst reports 
themselves (i.e. parse the text of analyst reports, not the data they use, to build second 
order databases) can become actionable data.

---

# **Exec Summary**

Can publicly available data on consumer complaints be reworked in such a way as to generate 
discernible alpha in investment returns? Turns out that yes. Here are the portfolio results.

![Image alt](/images/quant/us_portfolio_final.png)

Specifically, we use the publicly available Consumer Financial Protection Bureau’s (CFPB) 
[Complaints Database](https://www.consumerfinance.gov/data-research/consumer-complaints/). 
We tie the data to a universe of 25 publicly traded US consumer facing financial 
institutions. We extract features from the data and derive variables using textual analysis 
of the consumer complaint narratives.

The derived variable is year-on-year similarity / change score in the consumer complaint 
narratives. The main idea is that if the complaints a company receives change year on year, 
this means something. In this case, it turns out that companies with the largest change 
(i.e. changers) in their complaints outperform non-changers. Inspecting the differences 
visually, it’s clearly visible that Portfolio Q1 performed worst and Q5 second best. 
The 130/30 long-short portfolio is best.

 *change_score = 1 - similarity_score

---

# **1. Data Sourcing**

We use the Consumer Financial Protection Bureau’s (CFPB) [Complaints Database](https://www.consumerfinance.gov/data-research/consumer-complaints/). These are complaints made against financial products of particular companies (e.g. credit scoring, credit cards, loans). The database updates daily.

---

# **2. Feature Selection**

We’re mostly interested in the “Consumer complaint narrative” column, which contains unstructured text. While the database goes back to 2011, these consumer narratives only become available from 2015, giving us 7 years of data (Jan 2015 - Dec 2021) with a total of 841,219 non-empty entries (consumers elect whether to disclose their narrative).

![Image alt](/images/quant/feature_selection_1.png)

Since not all companies which receive complaints are publicly traded, for the purpose of this exercise we’ll just peel the top 25 from the top and ticker tie them later in the workflow.

![Image alt](/images/quant/feature_selection_2.png)

---

# **3. Textual Analysis**

Now we run the textual analysis:

- Convert dataframe to corpus format

- Make tokens out of the words

- Remove stop words (e.g. “a”, “the”)

- Stem the words (e.g. so we count “fraudulent” and “fraud” as same since stem would be “fraud”)

Just for demonstration purposes, after all this data wrangling we can run a word cloud visualisation. In this case we’re comparing across companies for 2021.

![Image alt](/images/quant/textual_analysis_1.png)

And here’s a word cloud across time for the same company, Wells Fargo.

![Image alt](/images/quant/textual_analysis_2.png)

For building intuition, we can also run a lexical dispersion plot for particular keywords that may be relevant in the financial context. In this case we plot “fraud”, “identity”, “violat*” for Wells Fargo by year.

![Image alt](/images/quant/textual_analysis_3.png)

---

# **4. Deriving Variables**

Here’s the key part. We want to calculate the similarity of each Company-Year’s worth of complaints to one another. E.g. We compare Wells Fargo complaints from 2021 to Wells Fargo complaints from 2020 using a similarity score for each year.

Here’s a visualisation of the similarity score (i.e. derived variable). A score of 1 means that the nature of this year’s versus the previous year’s complaints is identical. The closer to zero, the more different is one Company-Year to another. By definition then: 1 - similarity_score = change_score.

![Image alt](/images/quant/deriving_vars_1.png)

Going further, we can plot company migration through time and quantiles like so:

![Image alt](/images/quant/deriving_vars_2.png)

---

# **5. Quantile Segmentation**

To prepare the similarity score for testing, we need to:

- Rank companies by their similarity score by year

- Assign these to quintiles

- Create portfolio weights

- Run calculations and plot the portfolios

Here’s a visualisation of the weights. Since we have 25 stocks in our universe, a quintile will be 5 stocks. Within each quintile, each stock will take a 20% weighting.

![Image alt](/images/quant/quantile_segm_1.png)

And here’s a visualisation of the Q5-Q1 portfolio weight. This is a long-short portfolio. Long the stocks from the favoured quintile and short the stocks from the disfavoured quintile. The favoured quintile was then weighted at 130 and the disfavoured at 30 to give a 130/30 allocation. Notice that the long stocks sum to above 1.00 and the short stocks have negative weights and sum to -1/3.

![Image alt](/images/quant/quantile_segm_2.png)

---

# **6. Plotting Portfolio Performance**

Here are the resulting portfolios for each quintile. Inspecting the differences visually, it’s clear that Portfolio Q1 performed worst and Q5 second best. The 130/30 long-short portfolio is best.

![Image alt](/images/quant/us_portfolio_final.png)
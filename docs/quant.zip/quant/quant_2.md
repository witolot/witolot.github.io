---
bookToc: true
title: Satellite Night Time Lights (NTL) as Investment Signal for Indian Cement Stocks
weight: 2
---

{{< hint info >}}

# **Satellite Night Time Lights (NTL) as Investment Signal for Indian Cement Stocks**

{{< /hint >}}

---

{{< hint warning >}}

## **Contents**

1. Indian Cement Plants

2. Satellite Night Time Lights (NTL)

3. Tying Night Time Lights to Stock Performance

{{< /hint >}}

{{< hint danger >}}

*Not investment advice. Do your own research.

{{< /hint >}}

---

# **Why You Should Read This Post**

We prove that the simplest satellite Night Time Lights (NTL) signals can 
differentiate between publicly listed under- and out-performers. Now, we wouldn't 
necessarily trade Indian cement stocks. Nor would we really build a portfolio based only 
on one factor, this would have to be an input into a more sophisticated model. But the point 
is that this sort of analysis can be replicated for similar concepts anywhere in the world -- 
steel mills in China, miners in Australia, production facilities for electric vehicle 
makers in the US. 

One final point. The fact that satellite maps are publicly available and that someone with 
sufficient technical skills can access them isn't really an edge. The edge really lies in an 
analyst knowing where and why to look -- for any given company: which facilities matter, 
which ones don't, where are they, when did they come online, should we expect NTL emissions 
to be linearly correlated with earnings, what's the angle we're looking for?

---

# **Exec Summary**

Can satellite Night Time Lights (NTL) signals differentiate between under- and out-performers
in a sector? Turns out that they can.

![Image alt](/images/quant/cement_stocks_mvp.png)

Using NTL data, we can rank, sort, and go long a subset of all available Indian exchange (NSI) cement 
stocks to arrive at portfolios of varying performance. In this instance, the Q1 portofolio 
consists of the top 3 stocks with the largest average cement plant NTL values, i.e. go long 
the plants emitting the most lights in the previous month. Quantile 1 portfolio performs best. 
Quantile 5 the worst. Everything else in between in terms of NTL ranking is actually also in 
between in terms of stock performance. This is great validation of NTL as a discriminating variable.

---

# **1. Indian Cement Plants**

Data sources. Maps: Night time lights: NASA [BlackMarble](https://blackmarble.gsfc.nasa.gov/); 
Plant ownership data: [Spatial Finance Institute](https://www.cgfi.ac.uk/spatial-finance-initiative/).

![Image alt](/images/quant/india_map.png)

We first take a subset of all cement plants globally and focus only on those that are listed on the 
Indian NSI stock exchange. There is a number of plants operating in India that are not publicly listed. So our 
India subset is also a subset of total Indian production. When we map them out spatially, we 
get the map above. Some Indian companies own plants abroad.

![Image alt](/images/quant/number_of_plants.png)

Above is a list of Indian cement companies ranked by the number of plants they operate. 
ULTRACEMCO operates the most plants.

---

# **2. Satellite Night Time Lights (NTL)**

![Image alt](/images/big_themes/wuhan.png)

For a detailed write up about what Night Time Lights (NTL) are and how we validate the 
data set they provide, go to the post [here](https://witoldkozlowski.me/docs/big-themes/big_theme_1/).
As a quick recap, here is a satellite image of Wuhan before and after the onset of Covid (see above).
The NTL emissions are visibly lower after onset.

![Image alt](/images/quant/india_cement.png)

We now take all the Indian cement plants and aggregate their individual  time series. 
In the chart above, one can see total India cement production. 
Notice the very clear seasonality, corroborated qualitatively in this article [here](https://www.thehindubusinessline.com/blexplainer/why-is-indias-power-crisis-an-annual-affair/article65334286.ece).

![Image alt](/images/quant/plant_owner.png)

Now we perform the same aggregation exercise but instead of nationally we segment by 
plant owner (chart above). One can see that some are trending up, some are trending down, 
some are larger, some are smaller on average. Some visibly have some stop-and-go activity 
going on (e.g. MURLIIND).

---

# **3. Tying Night Time Lights to Stock Performance**

![Image alt](/images/quant/cement_stocks_mvp.png)

Using NTL data, we can rank, sort, and go long a subset of all available NSI cement 
stocks to arrive at portfolios of varying performance. In this instance, the Q1 portofolio 
consists of the top 3 stocks with the largest average cement plant NTL values, i.e. go long 
the plants emitting the most lights in the previous month. Quantile 1 portfolio performs best. 
Quantile 5 the worst. Everything else in between in terms of NTL ranking is actually also in 
between in terms of stock performance. This is great validation of NTL as a discriminating variable.